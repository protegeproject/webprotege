﻿import pandas as pd

gas_df = pd.read_csv('export-AvgGasPrice.csv')
eth_df = pd.read_csv('export-EtherPrice.csv')
eth_df.rename(columns={'Value': 'Value ETH/USD'}, inplace=True)
df = pd.concat([gas_df, eth_df['Value ETH/USD']], axis=1)
df.to_csv('export-eth-merged.csv', index=False)